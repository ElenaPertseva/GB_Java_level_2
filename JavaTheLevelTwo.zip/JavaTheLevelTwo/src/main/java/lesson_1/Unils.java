package lesson_1;

public class Unils {
    public static void makeAnimalOlder(Animal animal) {
        animal.setAge(animal.getAge() + 1);
    }
}
