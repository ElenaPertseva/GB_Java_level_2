package lesson_1;

public interface CanSwim {
    double swim(Pool pool);

}
