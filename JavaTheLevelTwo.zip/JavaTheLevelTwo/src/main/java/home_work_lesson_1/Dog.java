package home_work_lesson_1;

public  class Dog extends Animal {
    public Dog(String name){
        super("Пёс", "Тори", 100,100);
    }

    @Override
    public void jump(int height) {

    }
}
