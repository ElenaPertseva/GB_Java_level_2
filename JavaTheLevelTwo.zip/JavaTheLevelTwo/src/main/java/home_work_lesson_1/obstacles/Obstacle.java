package home_work_lesson_1.obstacles;

import home_work_lesson_1.Competitor;

public abstract class Obstacle {
    public abstract void doIt(Competitor competitor);
}
