package home_work_lesson_1.obstacles;

import home_work_lesson_1.Competitor;

public class Water extends Obstacle {
    private int distance;

    public Water(int distance) {
        this.distance = distance;
    }

    @Override
    public void doIt(Competitor competitor) {

    }
}
